package com.example.umbpage

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class REPLY_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.reply)

        val name = intent.getStringExtra("nombre")
        val l_name = intent.getStringExtra("apellido")
        val age = intent.getStringExtra("edad")

        val text = findViewById<TextView>(R.id.i)
        text.text = "Nombre: $name\nApellido: $l_name\nEdad: $age años"
    }
}