package com.example.umbpage

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.os.Handler

class SPLASH_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.splash)

        // Espera 3 segundos y pasa al menú principal
        Handler().postDelayed({
            startActivity(Intent(this, MENU_Activity::class.java))
            finish()
        }, 3000)
    }
}