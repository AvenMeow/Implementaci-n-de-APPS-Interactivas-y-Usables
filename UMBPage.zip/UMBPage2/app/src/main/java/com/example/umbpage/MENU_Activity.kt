package com.example.umbpage

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class MENU_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menu)

        val options = listOf("Página Institucional", "Buscar Páginas", "Mensajes")
        val list = findViewById<ListView>(R.id.listView1)

        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, options)

        list.setOnItemClickListener { _, _, position, _ ->
            when (position) {
                0 -> startActivity(Intent(this, UMB_Activity::class.java))
                1 -> startActivity(Intent(this, SEARCH_Activity::class.java))
                2 -> startActivity(Intent(this, FORM_Activity::class.java))
            }
        }
    }
}