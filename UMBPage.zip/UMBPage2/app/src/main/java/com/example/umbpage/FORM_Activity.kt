package com.example.umbpage

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class FORM_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.form)

        val name = findViewById<EditText>(R.id.nameView1)
        val l_name = findViewById<EditText>(R.id.l_nameView1)
        val age = findViewById<EditText>(R.id.ageView1)
        val send = findViewById<Button>(R.id.btnView2)

        send.setOnClickListener {
            val intent = Intent(this, REPLY_Activity::class.java)
            intent.putExtra("nombre", name.text.toString())
            intent.putExtra("apellido", l_name.text.toString())
            intent.putExtra("edad", age.text.toString())
            startActivity(intent)
        }
    }
}