package com.example.umbpage

import android.os.Bundle
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity

class UMB_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.umb)

        val web = findViewById<WebView>(R.id.webView1)
        web.settings.javaScriptEnabled = true
        web.loadUrl("https://umbvirtual.edu.co")
    }
}