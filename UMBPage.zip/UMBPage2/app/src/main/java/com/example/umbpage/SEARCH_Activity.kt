package com.example.umbpage

import android.os.Bundle
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity

class SEARCH_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.search)

        val input = findViewById<EditText>(R.id.urlView1)
        val button = findViewById<Button>(R.id.btnView1)
        val web = findViewById<WebView>(R.id.webView2)

        web.settings.javaScriptEnabled = true

        button.setOnClickListener {
            val url = input.text.toString()
            if (url.isNotEmpty()) {
                web.loadUrl(if (url.startsWith("http")) url else "https://$url")
            }
        }
    }
}